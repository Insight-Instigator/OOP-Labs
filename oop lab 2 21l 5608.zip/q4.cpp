#include<iostream>
using namespace std;
void copyArray(int* arr, int *&arr1, int n)
{
    for(int i=0;i<n;i++)
    arr1[i]=arr[i];
}
int reduceArray(int *arr, int *&arr1, int s)
{
    int newsize;
    cout<<"enter the size reduce the array:";
    cin>>newsize;
    s=s-newsize;
    for(int i=0;i<s;i++)
    {
        cout<<arr1[i]<<endl;
    }
    return s;
}

int main()
{
    int size;
     cout<<"enter the size please :";
     cin>>size;
    int* ptr1=new int[size];
	 int* ptr2=new int[size];
   for(int i=0;i<size;i++)
   {
       cout<<"enter th value of the array ";
       cin>>ptr1[i];
   }
      
       cout<<"dispalying the array 1 :"<<endl;
   copyArray(ptr1,ptr2,size);
   cout<<"output reduced array :"<<endl;
   reduceArray(ptr1,ptr2,size);
   delete []ptr1;
   ptr1=nullptr;
   delete []ptr2;
   ptr2=nullptr;
return 0;
}
