#include <iostream >
using namespace std ;
int main ()
{ 
	int size ;
	cout<<"enter the size of the array:  ";
	cin>>size;
	int*p=new int [size];
	p[0]=1;
	p[1]=1;
	for (int i=0;i<size;i++){
	
	p[i+2]=p[i]+p[i+1];
	}
for (int i=0;i<size;i++){
	cout<<"the fabonacci series upto the n numbers is "<<p[i]<<endl;
}
delete []p;
p=nullptr;
	system ("pause ");
	return 0;
}