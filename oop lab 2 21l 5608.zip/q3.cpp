//#include <iostream >
//using namespace std ;
//int main ()
//{
//	int size;
//	cout<<"enter the size of the array you want to make: ";
//	cin>>size;
//
//
