#include <iostream>
using namespace std ;
int output(int* p,int s)
{
	for (int i=0;i<s;i++)
	{
		cout<<p[i];
	}
}

int main ()
{
	int size ;
	cout<<"please enter the size of the arrray ";
	cin>>size;
	int*p=new int [size];
	for (int i=0;i<size;i++){
	p[0]=1;
	p[1]=1;
	p[i+2]=p[i]+p[i+1];
	}
	output (p,size);
	delete []p;
	system ("pause");
	return 0;
	}

