#include<iostream>
using namespace std;
void Input(int* ptr,int q)
{
  for(int i=0;i<q;i++)
{
    cout<<"enter"<<" "<<(i+1)<<" "<<"value :";
    cin>>ptr[i];
}  
}
void Compress(int* ar,int si)
{
    for(int i=0;i<si;i++)
    if(ar[i]!=ar[i+1]);
}
void Output(int* arr,int si2)
{
   for(int i=0;i<si2;i++)
{
    if(arr[i]!=arr[i+1])
    cout<<arr[i]<<endl;
}
}
int main()
{
int s;   //please enter the size of the array 
cout<<"enter the size of the array :";
cin>>s;
int* p=new int[s];
Input (p,s);
Compress(p,s);
Output(p,s);

system("pause");
return 0;
}
