#include <iostream >
using namespace std;
int main()
{ 
	float largenum=0;
	float seclarge=0;
	int size ;
	int index=0;
	cout<<"please enter the size of the array ";
	cin>>size;
float *p=new float [size];
cout<<"please enter the values of the array ";

for (int i=0;i<size;i++){
	cin>>p[i];
if (largenum<p[i]){
	seclarge=largenum;
	largenum=p[i];
	index=i-1;
}
else if (seclarge<p[i])
{
	index=i;
}
}
cout<<"the second largest number is "<<seclarge<<endl;
cout<<"the index of the number is "<<index<<endl;
delete []p;

system ("pause ");
return 0;
}